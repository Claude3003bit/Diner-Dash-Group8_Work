from MyGame import MyGame





        
if __name__ == "__main__":
    MyGame.main()
    